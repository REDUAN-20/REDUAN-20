
// (Full MainActivity.java code inserted here)
